---
tipo: concetto
area: Clienti
fonti: []
aggiornato: 2026-10-29
riservato: sì
---

# Clienti

Clienti rilevanti. Cartella esclusa da git: le pagine cliente si elencano solo qui.

## Pagine

Ancora nessuna: si riempie con l'ingest (vedi `CLAUDE.md`, «Stato dei lotti»).
